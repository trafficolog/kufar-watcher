#!/usr/bin/env python3
"""Apply the uncommitted, issue #72 MVP archive slice to a Kufar Watcher checkout.

Usage: python kufar-archive-implementation.py --check [path/to/kufar-watcher]
       python kufar-archive-implementation.py --apply [path/to/kufar-watcher]

Every edit is checked against exact main-branch anchors before any file is written.
No git commands that create commits, no database mutations and no network calls.
"""
import argparse
from pathlib import Path
import difflib
import sys

EDITS: dict[str, list[tuple[str, str]]] = {}

def edit(path: str, before: str, after: str) -> None:
    EDITS.setdefault(path, []).append((before, after))

# The renderer-facing type is the single authoritative IPC contract.
edit('shared/ipc.ts',
     '    list(): Promise<MonitorListItem[]>\n    setState(monitorId: number, state: \'active\' | \'paused\'): Promise<void>',
     '    list(archived?: boolean): Promise<MonitorListItem[]>\n    setState(monitorId: number, state: \'active\' | \'paused\' | \'archived\'): Promise<void>')

edit('shared/runtime.ts',
     "  | { type: 'monitor-list'; requestId: string }",
     "  | { type: 'monitor-list'; requestId: string; archived?: boolean }")
edit('shared/runtime.ts',
     "      state: 'active' | 'paused'\n",
     "      state: 'active' | 'paused' | 'archived'\n")
edit('shared/runtime.ts',
     "  | { type: 'monitor-set-state-error'; requestId: string }",
     "  | { type: 'monitor-set-state-error'; requestId: string; reason?: 'busy' | 'unsupported-api-mapping' | 'invalid-transition' }")

edit('electron/preload/desktop-api.ts',
     "      async list(): Promise<MonitorListItem[]> {\n        return (await ipcRenderer.invoke(IPC.monitorList)) as MonitorListItem[]",
     "      async list(archived = false): Promise<MonitorListItem[]> {\n        return (await ipcRenderer.invoke(IPC.monitorList, archived)) as MonitorListItem[]")

edit('electron/main/ipc-router.ts',
     "  listMonitors(): MonitorListItem[] | Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused'): void | Promise<void>",
     "  listMonitors(archived: boolean): MonitorListItem[] | Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused' | 'archived'): void | Promise<void>")
edit('electron/main/ipc-router.ts',
     "  ipcMain.handle(IPC.monitorList, (event) => {\n    assertTrustedRenderer(event, devRendererUrl)\n    return services.listMonitors()",
     "  ipcMain.handle(IPC.monitorList, (event, ...args) => {\n    assertTrustedRenderer(event, devRendererUrl)\n    return services.listMonitors(args[0] === true)")
edit('electron/main/ipc-router.ts',
     "return services.setMonitorState(args[0] as number, args[1] as 'active' | 'paused')",
     "return services.setMonitorState(args[0] as number, args[1] as 'active' | 'paused' | 'archived')")

edit('electron/main/index.ts',
     '      listMonitors: () => supervisor.listMonitors(),',
     '      listMonitors: (archived) => supervisor.listMonitors(archived),')

edit('electron/main/worker-supervisor.ts',
     "  listMonitors(): Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused'): Promise<void>",
     "  listMonitors(archived?: boolean): Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused' | 'archived'): Promise<void>")
edit('electron/main/worker-supervisor.ts',
     "  if (type === 'monitor-set-state-result' || type === 'monitor-set-state-error') {\n    const requestId = Reflect.get(message, 'requestId')\n    if (typeof requestId === 'string') return { type, requestId }\n  }",
     "  if (type === 'monitor-set-state-result' || type === 'monitor-set-state-error') {\n    const requestId = Reflect.get(message, 'requestId')\n    if (typeof requestId !== 'string') return undefined\n    if (type === 'monitor-set-state-result') return { type, requestId }\n    const reason = Reflect.get(message, 'reason')\n    if (reason === 'busy' || reason === 'unsupported-api-mapping' || reason === 'invalid-transition') {\n      return { type, requestId, reason }\n    }\n    return { type, requestId }\n  }")
edit('electron/main/worker-supervisor.ts',
     "          pending.reject(new Error('Monitor state update failed'))",
     "          const messages = {\n            busy: 'Монитор сейчас выполняет обход. Повторите действие после его завершения.',\n            'unsupported-api-mapping': 'Восстановление невозможно: ссылка не поддерживается текущей версией Kufar Monitor.',\n            'invalid-transition': 'Невозможно выполнить переход из архивного состояния.',\n          }\n          pending.reject(new Error(event.reason ? messages[event.reason] : 'Не удалось изменить состояние монитора.'))")
edit('electron/main/worker-supervisor.ts',
     '    listMonitors(): Promise<MonitorListItem[]> {',
     '    listMonitors(archived = false): Promise<MonitorListItem[]> {')
edit('electron/main/worker-supervisor.ts',
     "        worker.postMessage({ type: 'monitor-list', requestId })",
     "        worker.postMessage({ type: 'monitor-list', requestId, archived })")
edit('electron/main/worker-supervisor.ts',
     "    setMonitorState(monitorId: number, state: 'active' | 'paused'): Promise<void> {",
     "    setMonitorState(monitorId: number, state: 'active' | 'paused' | 'archived'): Promise<void> {")

edit('electron/worker/runtime.ts',
     "import type { MonitorCreateInput, MonitorCreateResult, MonitorListItem } from '../../shared/ipc'",
     "import type { MonitorCreateInput, MonitorCreateResult, MonitorListItem } from '../../shared/ipc'\nimport { KufarUrlBuildError } from '../../shared/kufar-url'\nimport { MonitorStateBusyError, MonitorStateTransitionError } from './monitor-config-sync'")
edit('electron/worker/runtime.ts',
     "  listMonitors?(): Promise<MonitorListItem[]>\n  setMonitorState?(monitorId: number, state: 'active' | 'paused'): Promise<void>",
     "  listMonitors?(archived?: boolean): Promise<MonitorListItem[]>\n  setMonitorState?(monitorId: number, state: 'active' | 'paused' | 'archived'): Promise<void>")
edit('electron/worker/runtime.ts',
     "  if (type === 'telegram-test-message' || type === 'monitor-list') {\n    return typeof Reflect.get(message, 'requestId') === 'string'\n  }",
     "  if (type === 'telegram-test-message') {\n    return typeof Reflect.get(message, 'requestId') === 'string'\n  }\n  if (type === 'monitor-list') {\n    return (\n      typeof Reflect.get(message, 'requestId') === 'string' &&\n      (Reflect.get(message, 'archived') === undefined || typeof Reflect.get(message, 'archived') === 'boolean')\n    )\n  }")
edit('electron/worker/runtime.ts',
     "      (state === 'active' || state === 'paused')",
     "      (state === 'active' || state === 'paused' || state === 'archived')")
edit('electron/worker/runtime.ts',
     "        .listMonitors()",
     "        .listMonitors(data.archived ?? false)")
edit('electron/worker/runtime.ts',
     "        .catch(() => {\n          parentPort.postMessage({\n            type: 'monitor-set-state-error',\n            requestId: data.requestId,\n          })",
     "        .catch((error: unknown) => {\n          const reason = error instanceof MonitorStateBusyError\n            ? 'busy'\n            : error instanceof KufarUrlBuildError\n              ? 'unsupported-api-mapping'\n              : error instanceof MonitorStateTransitionError\n                ? 'invalid-transition'\n                : undefined\n          parentPort.postMessage({\n            type: 'monitor-set-state-error',\n            requestId: data.requestId,\n            ...(reason ? { reason } : {}),\n          })")

# Archive and restore share the same persistence and scheduler synchronization path.
edit('electron/worker/monitor-config-sync.ts',
     "import type { MonitorCreateInput, MonitorCreateResult } from '../../shared/ipc'",
     "import type { MonitorCreateInput, MonitorCreateResult } from '../../shared/ipc'\nimport { buildKufarApiUrl } from '../../shared/kufar-url'\nimport type { AcquireMonitorRunLease } from './monitor-run-lease'")
edit('electron/worker/monitor-config-sync.ts',
     "  updateMonitorConfig,\n  type MonitorConfigPatch,",
     "  updateMonitorConfig,\n  parsePersistedCanonicalQuery,\n  type MonitorConfigPatch,")
edit('electron/worker/monitor-config-sync.ts',
     "export interface MonitorSchedulerSync {",
     "export class MonitorStateBusyError extends Error {\n  constructor() {\n    super('Monitor is running; retry after the current traversal')\n    this.name = 'MonitorStateBusyError'\n  }\n}\n\nexport class MonitorStateTransitionError extends Error {\n  constructor() {\n    super('Archived monitor can only be restored to active')\n    this.name = 'MonitorStateTransitionError'\n  }\n}\n\nexport interface MonitorSchedulerSync {")
edit('electron/worker/monitor-config-sync.ts',
     "export async function updateMonitorConfigAndSync(",
     "export async function setMonitorStateAndSync(\n  prisma: PrismaClient,\n  scheduler: MonitorSchedulerSync,\n  acquireRunLease: AcquireMonitorRunLease,\n  monitorId: number,\n  state: 'active' | 'paused' | 'archived',\n): Promise<void> {\n  const lease = await acquireRunLease(monitorId)\n  if (!lease) throw new MonitorStateBusyError()\n\n  try {\n    const current = await prisma.monitor.findUniqueOrThrow({\n      where: { id: monitorId },\n      select: { state: true, query: true },\n    })\n    if (current.state === 'archived' && state !== 'archived') {\n      if (state !== 'active') throw new MonitorStateTransitionError()\n      // Validate legacy persisted mappings before a destructive cursor reset or schedule creation.\n      buildKufarApiUrl(parsePersistedCanonicalQuery(current.query))\n    }\n    await updateMonitorConfigAndSync(prisma, scheduler, monitorId, { state })\n  } finally {\n    await lease.release()\n  }\n}\n\nexport async function updateMonitorConfigAndSync(")

edit('electron/worker/worker-application.ts',
     "import { createMonitorConfigAndSync, updateMonitorConfigAndSync } from './monitor-config-sync'",
     "import { createMonitorConfigAndSync, setMonitorStateAndSync } from './monitor-config-sync'")
edit('electron/worker/worker-application.ts',
     "  listMonitors(): Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused'): Promise<void>",
     "  listMonitors(archived?: boolean): Promise<MonitorListItem[]>\n  setMonitorState(monitorId: number, state: 'active' | 'paused' | 'archived'): Promise<void>")
edit('electron/worker/worker-application.ts',
     "      await updateMonitorConfigAndSync(prisma, scheduler, monitorId, { state })",
     "      await setMonitorStateAndSync(prisma, scheduler, acquireRunRecoveryLease, monitorId, state)")
edit('electron/worker/worker-application.ts',
     "    async listMonitors() {\n      const monitors = await prisma.monitor.findMany({\n        where: { state: { not: 'archived' } },",
     "    async listMonitors(archived = false) {\n      const monitors = await prisma.monitor.findMany({\n        where: archived ? { state: 'archived' } : { state: { not: 'archived' } },")

# A durable queue can already contain a job when its schedule is removed. Do not source-fetch it.
edit('electron/worker/scheduled-monitor-run.ts',
     "export interface SkippedOverlapMonitorRunResult {\n  cycleKind: 'skipped-overlap'\n}",
     "export interface SkippedOverlapMonitorRunResult {\n  cycleKind: 'skipped-overlap'\n}\n\nexport interface SkippedInactiveMonitorRunResult {\n  cycleKind: 'skipped-inactive'\n}")
edit('electron/worker/scheduled-monitor-run.ts',
     "      const adapters = options.createRunAdapters(onDegradation)\n\n      try {",
     "      try {")
edit('electron/worker/scheduled-monitor-run.ts',
     "  | SkippedOverlapMonitorRunResult\n",
     "  | SkippedOverlapMonitorRunResult\n  | SkippedInactiveMonitorRunResult\n")
edit('electron/worker/scheduled-monitor-run.ts',
     "          select: { query: true },\n        })\n        const query = parsePersistedCanonicalQuery(monitor.query)",
     "          select: { query: true, state: true },\n        })\n        if (monitor.state === 'paused' || monitor.state === 'archived') {\n          const finishedAt = new Date()\n          await options.prisma.run.update({\n            where: { id: journalRun.id },\n            data: {\n              finishedAt,\n              durationMs: Math.max(0, finishedAt.getTime() - startedAt.getTime()),\n              outcome: RUN_OUTCOME.SKIPPED,\n              seen: 0,\n              matched: 0,\n            },\n          })\n          return { cycleKind: 'skipped-inactive' }\n        }\n        const query = parsePersistedCanonicalQuery(monitor.query)")

edit('electron/worker/scheduled-monitor-run.ts',
     "        const adapter = adapters.get(routeKufarQuery(query))",
     "        const adapters = options.createRunAdapters(onDegradation)\n        const adapter = adapters.get(routeKufarQuery(query))")


# Guard before journal creation: stale queued jobs must not overwrite the last historical Run.
edit('electron/worker/scheduled-monitor-run.ts',
     "      const startedAt = new Date()\n      const journalRun = await options.prisma.run.create({",
     "      const monitor = await options.prisma.monitor.findUniqueOrThrow({\n        where: { id: monitorId },\n        select: { query: true, state: true },\n      })\n      if (monitor.state === 'paused' || monitor.state === 'archived') {\n        return { cycleKind: 'skipped-inactive' }\n      }\n\n      const startedAt = new Date()\n      const journalRun = await options.prisma.run.create({")
edit('electron/worker/scheduled-monitor-run.ts',
     "        const monitor = await options.prisma.monitor.findUniqueOrThrow({\n          where: { id: monitorId },\n          select: { query: true, state: true },\n        })\n        if (monitor.state === 'paused' || monitor.state === 'archived') {\n          const finishedAt = new Date()\n          await options.prisma.run.update({\n            where: { id: journalRun.id },\n            data: {\n              finishedAt,\n              durationMs: Math.max(0, finishedAt.getTime() - startedAt.getTime()),\n              outcome: RUN_OUTCOME.SKIPPED,\n              seen: 0,\n              matched: 0,\n            },\n          })\n          return { cycleKind: 'skipped-inactive' }\n        }\n        const query = parsePersistedCanonicalQuery(monitor.query)",
     "        const query = parsePersistedCanonicalQuery(monitor.query)")


# Previously queued Telegram notifications must be suppressed for an archived monitor.
edit('electron/worker/telegram-outbox-delivery.ts',
     "  getNotifiedAt(matchId: number): Promise<Date | null | undefined>",
     "  getNotifiedAt(matchId: number): Promise<Date | null | undefined>\n  isMonitorNotArchived?(matchId: number): Promise<boolean>")
edit('electron/worker/telegram-outbox-delivery.ts',
     "    const notifiedAt = await options.repository.getNotifiedAt(payload.matchId)\n    if (notifiedAt === undefined || notifiedAt !== null) return",
     "    const notifiedAt = await options.repository.getNotifiedAt(payload.matchId)\n    if (notifiedAt === undefined || notifiedAt !== null) return\n    if (options.repository.isMonitorNotArchived && !(await options.repository.isMonitorNotArchived(payload.matchId))) return")
edit('electron/worker/telegram-outbox-delivery.ts',
     "    lastAttemptAtByChat.set(payload.chatId, now().getTime())",
     "    // The monitor may have been archived during the chat throttle delay.\n    if (options.repository.isMonitorNotArchived && !(await options.repository.isMonitorNotArchived(payload.matchId))) return\n    lastAttemptAtByChat.set(payload.chatId, now().getTime())")
edit('electron/worker/telegram-outbox-delivery-repository.ts',
     "  return {\n    async getNotifiedAt(matchId): Promise<Date | null | undefined> {",
     "  return {\n    async isMonitorNotArchived(matchId): Promise<boolean> {\n      const match = await prisma.match.findUnique({\n        where: { id: matchId },\n        select: { monitor: { select: { state: true } } },\n      })\n      return match !== null && match.monitor.state !== 'archived'\n    },\n\n    async getNotifiedAt(matchId): Promise<Date | null | undefined> {")

# The UI exposes a reversible, confirmed action rather than deleting database records.
edit('app/pages/monitors.vue',
     "const monitors = ref<MonitorListItem[]>([])\n",
     "const monitors = ref<MonitorListItem[]>([])\nconst archivedMonitors = ref<MonitorListItem[]>([])\nconst archiveCandidateId = ref<number | null>(null)\n")
edit('app/pages/monitors.vue',
     "    const next = await useDesktopApi().monitors.list()\n    if (request !== monitorListRequest) return\n    monitors.value = next",
     "    const [next, archived] = await Promise.all([\n      useDesktopApi().monitors.list(),\n      useDesktopApi().monitors.list(true),\n    ])\n    if (request !== monitorListRequest) return\n    monitors.value = next\n    archivedMonitors.value = archived")
edit('app/pages/monitors.vue',
     'async function submit(): Promise<void> {',
     "async function archiveMonitor(monitor: MonitorListItem): Promise<void> {\n  if (stateChangingId.value !== null || archiveCandidateId.value !== monitor.id) return\n  stateChangingId.value = monitor.id\n  listError.value = ''\n  try {\n    await useDesktopApi().monitors.setState(monitor.id, 'archived')\n    archiveCandidateId.value = null\n    await refreshMonitors()\n  } catch (error) {\n    listError.value = error instanceof Error ? error.message : 'Не удалось архивировать монитор.'\n  } finally {\n    stateChangingId.value = null\n  }\n}\n\nasync function restoreMonitor(monitor: MonitorListItem): Promise<void> {\n  if (stateChangingId.value !== null) return\n  stateChangingId.value = monitor.id\n  listError.value = ''\n  try {\n    await useDesktopApi().monitors.setState(monitor.id, 'active')\n    await refreshMonitors()\n  } catch (error) {\n    listError.value = error instanceof Error ? error.message : 'Не удалось восстановить монитор.'\n  } finally {\n    stateChangingId.value = null\n  }\n}\n\nasync function submit(): Promise<void> {")
edit('app/pages/monitors.vue',
     "            </button>\n          </article>\n        </div>\n      </section>\n\n      <section v-if=\"showCreate\"",
     "            </button>\n            <div>\n              <button\n                class=\"secondary\"\n                type=\"button\"\n                :disabled=\"stateChangingId !== null\"\n                @click=\"archiveCandidateId = monitor.id\"\n              >\n                В архив\n              </button>\n              <div v-if=\"archiveCandidateId === monitor.id\" role=\"group\" :aria-label=\"`Подтверждение архивирования ${monitor.name}`\">\n                <p>Монитор «{{ monitor.name }}» перестанет отслеживаться. История останется.</p>\n                <button class=\"secondary\" type=\"button\" :disabled=\"stateChangingId !== null\" @click=\"archiveMonitor(monitor)\">\n                  {{ stateChangingId === monitor.id ? 'Архивирую…' : 'Подтвердить архивирование' }}\n                </button>\n                <button class=\"link-button\" type=\"button\" :disabled=\"stateChangingId !== null\" @click=\"archiveCandidateId = null\">Отмена</button>\n              </div>\n            </div>\n          </article>\n        </div>\n      </section>\n\n      <section class=\"monitor-section\" aria-labelledby=\"archive-list-heading\">\n        <div class=\"section-heading\">\n          <div>\n            <p class=\"eyebrow\">История</p>\n            <h2 id=\"archive-list-heading\">Архив · {{ archivedMonitors.length }}</h2>\n          </div>\n        </div>\n        <p v-if=\"archivedMonitors.length === 0\" class=\"empty-state\">Архив пока пуст.</p>\n        <div v-else class=\"monitor-list\">\n          <article v-for=\"monitor in archivedMonitors\" :key=\"monitor.id\" class=\"monitor-row\">\n            <div class=\"monitor-main\">\n              <h3>{{ monitor.name }}</h3>\n              <p class=\"monitor-meta\">В архиве · обходы остановлены; история сохранена.</p>\n            </div>\n            <dl class=\"run-summary\">\n              <div><dt>Последний обход</dt><dd>{{ lastRunTime(monitor) }}</dd></div>\n              <div><dt>Результат</dt><dd :class=\"lastRunResult(monitor).tone\">{{ lastRunResult(monitor).label }}</dd></div>\n            </dl>\n            <button class=\"secondary\" type=\"button\" :disabled=\"stateChangingId !== null\" @click=\"restoreMonitor(monitor)\">\n              {{ stateChangingId === monitor.id ? 'Восстанавливаю…' : 'Вернуть в работу' }}\n            </button>\n          </article>\n        </div>\n      </section>\n\n      <section v-if=\"showCreate\"")


# Keep both actions in the existing third grid cell, including on narrow screens.
edit('app/pages/monitors.vue',
     '            <button\n              class="secondary"\n              type="button"\n              :disabled="stateChangingId !== null"\n              @click="toggleMonitorState(monitor)"',
     '            <div class="monitor-actions">\n              <button\n              class="secondary"\n              type="button"\n              :disabled="stateChangingId !== null"\n              @click="toggleMonitorState(monitor)"')
edit('app/pages/monitors.vue',
     '              </div>\n            </div>\n          </article>\n        </div>\n      </section>\n\n      <section class="monitor-section"',
     '              </div>\n            </div>\n            </div>\n          </article>\n        </div>\n      </section>\n\n      <section class="monitor-section"')
edit('app/pages/monitors.vue',
     '.monitor-title-row {',
     '.monitor-actions {\n  display: grid;\n  gap: 8px;\n  justify-items: start;\n}\n\n.archive-confirmation {\n  max-width: 250px;\n  overflow-wrap: anywhere;\n}\n\n.monitor-title-row {')
edit('app/pages/monitors.vue',
     '.section-heading {\n  margin-bottom: 14px;\n}',
     '.section-heading {\n  margin-bottom: 14px;\n}\n\n.monitor-section + .monitor-section {\n  margin-top: 32px;\n}')
edit('app/pages/monitors.vue',
     '              <div v-if="archiveCandidateId === monitor.id" role="group"',
     '              <div v-if="archiveCandidateId === monitor.id" class="archive-confirmation" role="group"')

TEST_CONTENT = '''import { describe, expect, it, vi } from 'vitest'
import type { Prisma, PrismaClient } from '../../generated/prisma/client'
import {
  MonitorStateBusyError,
  MonitorStateTransitionError,
  setMonitorStateAndSync,
} from '../../electron/worker/monitor-config-sync'
import { KufarUrlBuildError } from '../../shared/kufar-url'
import { createScheduledMonitorRunExecutor } from '../../electron/worker/scheduled-monitor-run'
import { createTelegramOutboxDelivery } from '../../electron/worker/telegram-outbox-delivery'

function persistedQuery(region: string | null = 'minsk') {
  return {
    host: 'www.kufar.by', category: 'igry-i-pristavki', query: null,
    region, sellerType: null, sort: 'lst.d', operation: null,
    pathFilters: [], extraParams: {},
  }
}

function harness(initialState: 'active' | 'paused' | 'archived', region: string | null = 'minsk') {
  const calls: string[] = []
  const row = {
    sourceUrl: 'https://www.kufar.by/l/r~minsk/igry-i-pristavki',
    query: persistedQuery(region),
    state: initialState,
  }
  const tx = {
    monitor: {
      findUniqueOrThrow: vi.fn().mockImplementation(async () => row),
      update: vi.fn().mockImplementation(async ({ data }: { data: { state?: typeof row.state } }) => {
        row.state = data.state ?? row.state
        calls.push(`update:${row.state}`)
      }),
    },
    monitorCursor: { deleteMany: vi.fn().mockImplementation(async () => { calls.push('cursor-reset') }) },
  } as unknown as Prisma.TransactionClient
  const prisma = {
    monitor: { findUniqueOrThrow: vi.fn().mockImplementation(async () => row) },
    $transaction: vi.fn().mockImplementation(async (callback: (tx: Prisma.TransactionClient) => Promise<void>) => {
      await callback(tx)
      calls.push('commit')
    }),
  } as unknown as PrismaClient
  const scheduler = { syncMonitor: vi.fn().mockImplementation(async () => { calls.push('reconcile') }) }
  const release = vi.fn().mockImplementation(async () => { calls.push('release') })
  const acquire = vi.fn().mockResolvedValue({ release })
  return { prisma, scheduler, acquire, calls, row, tx, release }
}

describe('reversible MVP archive state mutation', () => {
  it('archives through transaction then scheduler without deleting cursor or history', async () => {
    const h = harness('active')
    await setMonitorStateAndSync(h.prisma, h.scheduler, h.acquire, 1, 'archived')
    expect(h.row.state).toBe('archived')
    expect(h.calls).toEqual(['update:archived', 'commit', 'reconcile', 'release'])
    expect(h.tx.monitorCursor.deleteMany).not.toHaveBeenCalled()
    expect(h.acquire).toHaveBeenCalledWith(1)
  })

  it('does not mutate a monitor while another traversal owns its lease', async () => {
    const h = harness('active')
    h.acquire.mockResolvedValue(null)
    await expect(setMonitorStateAndSync(h.prisma, h.scheduler, h.acquire, 1, 'archived'))
      .rejects.toBeInstanceOf(MonitorStateBusyError)
    expect(h.calls).toEqual([])
  })

  it('refuses to restore a legacy unsupported query without changing state or cursor', async () => {
    const h = harness('archived', null)
    await expect(setMonitorStateAndSync(h.prisma, h.scheduler, h.acquire, 1, 'active'))
      .rejects.toBeInstanceOf(KufarUrlBuildError)
    expect(h.row.state).toBe('archived')
    expect(h.calls).toEqual(['release'])
  })

  it('restores a supported query and resets its cursor only after validation', async () => {
    const h = harness('archived')
    await setMonitorStateAndSync(h.prisma, h.scheduler, h.acquire, 1, 'active')
    expect(h.row.state).toBe('active')
    expect(h.calls).toEqual(['update:active', 'cursor-reset', 'commit', 'reconcile', 'release'])
  })

  it('does not allow archived-to-paused to bypass restore validation', async () => {
    const h = harness('archived', null)
    await expect(setMonitorStateAndSync(h.prisma, h.scheduler, h.acquire, 1, 'paused'))
      .rejects.toBeInstanceOf(MonitorStateTransitionError)
    expect(h.calls).toEqual(['release'])
  })

  it('skips a queued archived monitor without constructing an adapter or fetching Kufar', async () => {
    const runUpdate = vi.fn().mockResolvedValue(undefined)
    const prisma = {
      monitor: {
        findUniqueOrThrow: vi.fn().mockResolvedValue({ state: 'archived', query: persistedQuery() }),
      },
      run: {
        create: vi.fn().mockResolvedValue({ id: 5 }),
        update: runUpdate,
      },
    } as unknown as PrismaClient
    const createRunAdapters = vi.fn(() => { throw new Error('Adapter must not be constructed') })
    const executor = createScheduledMonitorRunExecutor({
      prisma,
      acquireMonitorRunLease: vi.fn().mockResolvedValue({ release: vi.fn().mockResolvedValue(undefined) }),
      createRunAdapters,
      maxPages: 5,
      descriptionLoader: { ensureDescription: vi.fn() },
      runCycle: vi.fn() as never,
    })
    await expect(executor(1)).resolves.toEqual({ cycleKind: 'skipped-inactive' })
    expect(createRunAdapters).not.toHaveBeenCalled()
    expect(prisma.run.create).not.toHaveBeenCalled()
    expect(runUpdate).not.toHaveBeenCalled()
  })

  it('does not deliver queued Telegram notifications from archived monitors', async () => {
    const repository = {
      getNotifiedAt: vi.fn().mockResolvedValue(null),
      isMonitorNotArchived: vi.fn().mockResolvedValue(false),
      markSending: vi.fn(),
      markNotified: vi.fn(),
    }
    const sendMessage = vi.fn()
    const delivery = createTelegramOutboxDelivery({ repository, sendMessage })
    await delivery({ matchId: 11, chatId: '42', text: 'archived', openUrl: 'https://kufar.by/item/1' })
    expect(sendMessage).not.toHaveBeenCalled()
    expect(repository.markSending).not.toHaveBeenCalled()
  })

  it('rechecks archive state after Telegram throttle sleep', async () => {
    let archived = false
    const repository = {
      getNotifiedAt: vi.fn().mockResolvedValue(null),
      isMonitorNotArchived: vi.fn().mockImplementation(async () => !archived),
      markSending: vi.fn(),
      markNotified: vi.fn(),
    }
    const sendMessage = vi.fn()
    const delivery = createTelegramOutboxDelivery({
      repository, sendMessage,
      now: () => new Date('2026-09-16T08:00:00Z'),
      sleep: async () => { archived = true },
    })
    await delivery({ matchId: 1, chatId: '42', text: 'first', openUrl: 'https://kufar.by/item/1' })
    await delivery({ matchId: 2, chatId: '42', text: 'second', openUrl: 'https://kufar.by/item/2' })
    expect(sendMessage).toHaveBeenCalledTimes(1)
  })
})
'''


def transform(path: str, source: str) -> str:
    result = source
    for before, after in EDITS[path]:
        occurrence = result.count(before)
        if occurrence != 1:
            raise ValueError(f'{path}: expected exactly one anchor, found {occurrence}: {before[:90]!r}')
        result = result.replace(before, after, 1)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true', help='verify anchors, do not write')
    group.add_argument('--apply', action='store_true', help='modify working tree without commit')
    parser.add_argument('checkout', nargs='?', default='.', type=Path)
    args = parser.parse_args()
    root = args.checkout.resolve()
    output: dict[Path, str] = {}
    try:
        for relative in EDITS:
            file = root / relative
            raw = file.read_bytes().decode('utf-8')
            newline = '\r\n' if '\r\n' in raw else '\n'
            original = raw.replace('\r\n', '\n')
            updated = transform(relative, original)
            output[file] = updated.replace('\n', newline)
        test = root / 'tests/unit/monitor-archive-state.test.ts'
        if test.exists():
            raise ValueError(f'Test file already exists (do not overwrite): {test}')
        if args.apply:
            for path, text in output.items():
                path.write_bytes(text.encode('utf-8'))
            test.parent.mkdir(parents=True, exist_ok=True)
            test.write_text(TEST_CONTENT, encoding='utf-8', newline='')
            print(f'Applied uncommitted archive changes to {len(output)} existing files + 1 new test.')
            print('Review: git diff --check && git diff; run npm test -- tests/unit/monitor-archive-state.test.ts')
        else:
            print(f'CHECK OK: {len(output)} existing files + 1 new test; no files changed.')
        return 0
    except (OSError, ValueError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        print('No changes made if validation failed.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
